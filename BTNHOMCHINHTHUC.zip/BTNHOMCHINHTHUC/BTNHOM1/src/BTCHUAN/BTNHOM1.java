/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BTCHUAN;

/**
 *
 * @author HP
 */
public class BTNHOM1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
//        NhanVien nv1 = new NhanVien("jhds","tranhvan","123");
//        NhanVien nv2 = new NhanVien("jhds","tranhvan2","123");
//        NhanVien nv3 = new NhanVien("jhds","tranhvan3","123");
//        dsNV.themNV(nv1);
//        dsNV.themNV(nv3);
//        dsNV.themNV(nv2);
        DangNhap a= new DangNhap();
        a.show();
        DangKy b= new DangKy();
        b.show();
    }
//    
}
