/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BTCHUAN;

import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author HP
 */
public class PHIM {
    protected String maPhim;
    protected String tenPhim;
    protected String theLoaiPhim;
    protected String gioiHan;
    protected int tonKho;
    protected int daBan;
    protected int namSanXuat;
    protected double giaBan;

    public PHIM() {
    }
    public String randomID(){
        return (ThreadLocalRandom.current().nextInt(1,101))+"";
    }
    public PHIM( String tenPhim, String theLoaiPhim, String gioiHan, int tonKho, int daBan, int namSanXuat, double giaBan) {
        this.maPhim = randomID();
        this.tenPhim = tenPhim;
        this.theLoaiPhim = theLoaiPhim;
        this.gioiHan = gioiHan;
        this.tonKho = tonKho;
        this.daBan = daBan;
        this.namSanXuat = namSanXuat;
        this.giaBan = giaBan;
    }

    public String getMaPhim() {
        return maPhim;
    }

    public void setMaPhim(String maPhim) {
        this.maPhim = maPhim;
    }

    public String getTenPhim() {
        return tenPhim;
    }

    public void setTenPhim(String tenPhim) {
        this.tenPhim = tenPhim;
    }

    public String getTheLoaiPhim() {
        return theLoaiPhim;
    }

    public void setTheLoaiPhim(String theLoaiPhim) {
        this.theLoaiPhim = theLoaiPhim;
    }

    public String getGioiHan() {
        return gioiHan;
    }

    public void setGioiHan(String gioiHan) {
        this.gioiHan = gioiHan;
    }

    public int getTonKho() {
        return tonKho;
    }

    public void setTonKho(int tonKho) {
        this.tonKho = tonKho;
    }

    public int getDaBan() {
        return daBan;
    }

    public void setDaBan(int daBan) {
        this.daBan = daBan;
    }

    public int getNamSanXuat() {
        return namSanXuat;
    }

    public void setNamSanXuat(int namSanXuat) {
        this.namSanXuat = namSanXuat;
    }

    public double getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(double giaBan) {
        this.giaBan = giaBan;
    }
 
}
