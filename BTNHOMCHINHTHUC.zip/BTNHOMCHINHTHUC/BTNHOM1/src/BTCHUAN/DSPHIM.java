
package BTCHUAN;

import java.util.ArrayList;


public class DSPHIM {
    ArrayList<PHIM>ds;

    public DSPHIM() {
        ds = new ArrayList<PHIM>();
    }

    public DSPHIM(ArrayList<PHIM> ds) {
        this.ds = ds;
    }

    public ArrayList<PHIM> getDs(){
        return ds;
    }
    
    public void setDs(ArrayList<PHIM> ds) {
        this.ds = ds;
    }

 
    public void ThemP(PHIM p){
        ds.add(p);
    }
    public void SuaP(PHIM p){
        for(int i=0;i<ds.size();i++){
            if(p.getMaPhim().trim().equalsIgnoreCase(ds.get(i).getMaPhim())){
                ds.set(i,p);
            }
        }
    }
    public PHIM TimP(String maPhim){
        for(int i=0;i<ds.size();i++){
            if(ds.get(i).getMaPhim().equalsIgnoreCase(maPhim)){
                return ds.get(i);
            }
        }
        return null;
    }
    public void XoaP(String maPhim){
        for(int i=0;i<ds.size();i++){
            if(ds.get(i).getMaPhim().equalsIgnoreCase(maPhim)){
                ds.remove(i);
                break;
            }
        }
    }
}
