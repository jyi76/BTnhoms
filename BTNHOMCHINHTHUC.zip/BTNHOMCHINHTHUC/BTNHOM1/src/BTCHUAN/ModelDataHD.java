/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BTCHUAN;

import java.util.ArrayList;
import java.util.Date;
import javax.swing.table.AbstractTableModel;


public class ModelDataHD extends AbstractTableModel{
    ArrayList<HOADON> data;

    public ArrayList<HOADON> getData() {
        return data;
    }

    public void setData(ArrayList<HOADON> data) {
        this.data = data;
    }

    public ModelDataHD() {
        data= new ArrayList<HOADON>();
    }
    String colNames[]={"Mã Hóa Đơn","Mã Sản Phẩm","Số Lượng","Thanh Toán"};
    Class<?> colClasses[]={String.class,String.class,String.class,int.class,double.class};

    public ModelDataHD(ArrayList<HOADON> nv) {
        data = nv;
    }
    @Override
    public int getRowCount(){
        return data.size();
    }
    @Override
    public int getColumnCount(){
        return colNames.length;
    } 

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        if(columnIndex==0){
            return data.get(rowIndex).getMaHoaDon();
        }
        if(columnIndex==1){
            return data.get(rowIndex).getMaSP();
        }
        if(columnIndex==1){
            return data.get(rowIndex).getSoLuong();
        }
        if(columnIndex==1){
            return data.get(rowIndex).ThanhToan();
        }
        return null;
    }
    @Override
    public String getColumnName(int columnIndex){
        String name=null;
        switch(columnIndex){
            case 0:
                name=colNames[0];
                break;
            case 1:
                name=colNames[1];
                break;
            case 2:
                name=colNames[2];
                break;
            case 3:
                name=colNames[3];
                break;
 
        }
        return name;
    }
    @Override
    public Class<?>getColumnClass(int columnIndex){
        return colClasses[columnIndex];
    }
    @Override
    public boolean isCellEditable(int rowIndex,int columnIndex){
        return true;
    }
}
