
package BTCHUAN;

import java.util.ArrayList;


public class DSHOADON {
    ArrayList<HOADON>ds;

    public DSHOADON() {
        ds = new ArrayList<HOADON>();
    }

    public DSHOADON(ArrayList<HOADON> ds) {
        this.ds = ds;
    }

    public ArrayList<HOADON> getDs(){
        return ds;
    }
    
    public void setDs(ArrayList<HOADON> ds) {
        this.ds = ds;
    }

 
    public void ThemP(HOADON hd){
        ds.add(hd);
    }
    public void SuaHD(HOADON p){
        for(int i=0;i<ds.size();i++){
            if(p.getMaHoaDon().trim().equalsIgnoreCase(ds.get(i).getMaHoaDon())){
                ds.set(i,p);
            }
        }
    }
    public HOADON TimHD(String maHD){
        for(int i=0;i<ds.size();i++){
            if(ds.get(i).getMaHoaDon().equalsIgnoreCase(maHD)){
                return ds.get(i);
            }
        }
        return null;
    }
    public void XoaP(String maPhim){
        for(int i=0;i<ds.size();i++){
            if(ds.get(i).getMaHoaDon().equalsIgnoreCase(maPhim)){
                ds.remove(i);
                break;
            }
        }
    }
}
