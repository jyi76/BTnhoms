/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BTCHUAN;

import java.util.ArrayList;
import java.util.Date;
import javax.swing.table.AbstractTableModel;


public class ModelDataAC extends AbstractTableModel{
    ArrayList<ACCOUNT> data;

    public ArrayList<ACCOUNT> getData() {
        return data;
    }

    public void setData(ArrayList<ACCOUNT> data) {
        this.data = data;
    }

    public ModelDataAC() {
        data= new ArrayList<ACCOUNT>();
    }
    String colNames[]={"MaNV","Hoten"};
    Class<?> colClasses[]={String.class,String.class};

    public ModelDataAC(ArrayList<ACCOUNT> ac) {
        data = ac;
    }
    @Override
    public int getRowCount(){
        return data.size();
    }
    @Override
    public int getColumnCount(){
        return colNames.length;
    } 

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        if(columnIndex==0){
            return data.get(rowIndex).getEmpID();
        }
        if(columnIndex==1){
            return data.get(rowIndex).getName();
        }
        
        return null;
    }
    @Override
    public String getColumnName(int columnIndex){
        String name=null;
        switch(columnIndex){
            case 0:
                name=colNames[0];
                break;
            case 1:
                name=colNames[1];
                break;

        }
        return name;
    }
    @Override
    public Class<?>getColumnClass(int columnIndex){
        return colClasses[columnIndex];
    }
    @Override
    public boolean isCellEditable(int rowIndex,int columnIndex){
        return true;
    }
}
