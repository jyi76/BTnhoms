/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BTCHUAN;

import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author HP
 */
public class HOADON {
    private String maHoaDon;
    private int soLuong;
    private String maSP;
    private double giaBan;
    public HOADON() {
    }

    public HOADON(String maHoaDon, int soLuong, String maSP, double giaBan) {
        this.maHoaDon = maHoaDon;
        this.soLuong = soLuong;
        this.maSP = maSP;
        this.giaBan = giaBan;
    }

    public String getMaHoaDon() {
        return maHoaDon;
    }

    public void setMaHoaDon(String maHoaDon) {
        this.maHoaDon = maHoaDon;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public String getMaSP() {
        return maSP;
    }

    public void setMaSP(String maSP) {
        this.maSP = maSP;
    }

    public double getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(double giaBan) {
        this.giaBan = giaBan;
    }

    public String randomID(){
        return (ThreadLocalRandom.current().nextInt(1,101))+"";
    }

    public double ThanhToan(){
        return soLuong*giaBan;
    }
    
}
