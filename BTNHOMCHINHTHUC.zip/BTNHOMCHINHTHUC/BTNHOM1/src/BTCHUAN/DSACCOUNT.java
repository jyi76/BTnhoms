
package BTCHUAN;

import java.util.ArrayList;


public class DSACCOUNT {
    ArrayList<ACCOUNT>ds;

    public DSACCOUNT() {
        ds = new ArrayList<ACCOUNT>();
    }

    public DSACCOUNT(ArrayList<ACCOUNT> ds) {
        this.ds = ds;
    }

    public ArrayList<ACCOUNT> getDs(){
        return ds;
    }
    
    public void setDs(ArrayList<ACCOUNT> ds) {
        this.ds = ds;
    }

 
    public void ThemAC(ACCOUNT ac){
        ds.add(ac);
    }
    public void SuaAC(ACCOUNT ac){
        for(int i=0;i<ds.size();i++){
            if(ac.getEmpID().trim().equalsIgnoreCase(ds.get(i).getEmpID())){
                ds.set(i, ac);
            }
        }
    }
    public ACCOUNT TimAC(String empID){
        for(int i=0;i<ds.size();i++){
            if(ds.get(i).getEmpID().equalsIgnoreCase(empID)){
                return ds.get(i);
            }
        }
        return null;
    }
    public ACCOUNT TimACtheoTDN(String tenDangNhap){
        for(int i=0;i<ds.size();i++){
            if(ds.get(i).getTenDN().equalsIgnoreCase(tenDangNhap)){
                return ds.get(i);
            }
        }
        return null;
    }
    public void XoaAC(String empID){
        for(int i=0;i<ds.size();i++){
            if(ds.get(i).getEmpID().equalsIgnoreCase(empID)){
                ds.remove(i);
                break;
            }
        }
    }
}
