/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BTCHUAN;

import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author HP
 */
public class ACCOUNT {
    private String empID;
    private String name;
    private String tenDN;
    private String matKhau;

    public ACCOUNT() {
    }

    public ACCOUNT(String name, String tenDN, String matKhau) {
        this.empID = randomID();
        this.name = name;
        this.tenDN = tenDN;
        this.matKhau = matKhau;
    }
    
    public String randomID(){
        return (ThreadLocalRandom.current().nextInt(1,101))+"";
    }

    public String getEmpID() {
        return empID;
    }

    public void setEmpID(String empID) {
        this.empID = empID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTenDN() {
        return tenDN;
    }

    public void setTenDN(String tenDN) {
        this.tenDN = tenDN;
    }

    public String getMatKhau() {
        return matKhau;
    }

    public void setMatKhau(String matKhau) {
        this.matKhau = matKhau;
    }
    
    
}
