/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BTCHUAN;

import java.util.ArrayList;
import java.util.Date;
import javax.swing.table.AbstractTableModel;


public class ModelDataPHIM extends AbstractTableModel{
    ArrayList<PHIM> data;

    public ArrayList<PHIM> getData() {
        return data;
    }

    public void setData(ArrayList<PHIM> data) {
        this.data = data;
    }

    public ModelDataPHIM() {
        data= new ArrayList<PHIM>();
    }
    String colNames[]={"Mã Phim","Thể Loại Phim","Tên Phim","Năm Sản Xuất","Tồn Kho","Giá Bán"};
    Class<?> colClasses[]={String.class,String.class,String.class,String.class,int.class,int.class};

    public ModelDataPHIM(ArrayList<PHIM> p) {
        data = p;
    }
    @Override
    public int getRowCount(){
        return data.size();
    }
    @Override
    public int getColumnCount(){
        return colNames.length;
    } 

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        if(columnIndex==0){
            return data.get(rowIndex).getMaPhim();
        }
        if(columnIndex==1){
            return data.get(rowIndex).getTheLoaiPhim();
        }
        if(columnIndex==2){
            return data.get(rowIndex).getTenPhim();
        }
        if(columnIndex==3){
            return data.get(rowIndex).getNamSanXuat();
        }
        if(columnIndex==4){
            return data.get(rowIndex).getTonKho();
        }
        if(columnIndex==5){
            return data.get(rowIndex).getGiaBan();
        }
        
        return null;
    }
    @Override
    public String getColumnName(int columnIndex){
        String name=null;
        switch(columnIndex){
            case 0:
                name=colNames[0];
                break;
            case 1:
                name=colNames[1];
                break;
            case 2:
                name=colNames[2];
                break;
            case 3:
                name=colNames[3];
                break;
            case 4:
                name=colNames[4];
                break;
            case 5:
                name=colNames[5];
                break;

        }
        return name;
    }
    @Override
    public Class<?>getColumnClass(int columnIndex){
        return colClasses[columnIndex];
    }
    @Override
    public boolean isCellEditable(int rowIndex,int columnIndex){
        return true;
    }
}
